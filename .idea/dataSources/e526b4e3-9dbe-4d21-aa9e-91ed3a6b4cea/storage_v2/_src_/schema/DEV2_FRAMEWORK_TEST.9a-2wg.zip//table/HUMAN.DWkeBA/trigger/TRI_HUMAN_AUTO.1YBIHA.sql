create trigger TRI_HUMAN_AUTO
  before insert
  on HUMAN
  for each row
  when (new.HID is null)
begin
    select SEQ_HUMAN_Hid.nextval into:new.HID from dual;
    end;
/

