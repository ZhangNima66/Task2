create view V_WF_BIZ_PROCESS as
select t1."ID",
       t1."RECORD_ID",
       t1."PROCESSINSTANCE_ID",
       t1."PROCESSDEFINITION_ID",
       t1."RECORDSTATE",
       t1."PROCESSDEFINITION_NAME",
       (select t6.detail from dictionary t6 where t6.code = t1.processdefinition_name and t6.kind='WORKFLOW_BIZ_PROCESS') "PROCESSDEFINITION_NAME_DETAIL",
       t1."CALLERPROCESSINSTANCEID",
       t1."ORG_CODE",
       t2."ID_",
       t2."VERSION_",
       t2."KEY_",
       t2."START_",
       t2."END_",
       t2."ISSUSPENDED_",
       t2."PROCESSDEFINITION_",
       t2."ROOTTOKEN_",
       t2."SUPERPROCESSTOKEN_",
     t3.id as process_transaction_id,
      --查出流程当前所处的环节
       t3.node_name,
       --查出流程当前在处理的人或角色，这里的查询比较慢
     (case
                  when t3.assignmenttype = '1' then
                   (select t4.username
                      from s_user t4
                     where t4.userid = t3.assignment)
                  else
                   (select t5.groupname
                      from s_user_role t5
                     where t5.groupid = t3.assignment)
                end) assignment,
        t3.assignment as assignment_id,
         (case when length(t2.end_) > 0 then '1' else '0' end) sfjs,--流程是否结束
          (select d1.detail from dictionary d1 where d1.kind='WORKFLOW_BIZ_PROCESS' and d1.code=t1.processdefinition_name) biz_type--业务类型代码
   from c_wf_record_mapping t1, jbpm_processinstance t2,c_wf_process_transaction t3
 where t1.processinstance_id = t2.id_ and t3.record_process_mapping_id=t1.id and t3.state='0'


/

