create view V_WF_TRANSACTION_LOG as
select t."ID",t."RECORD_PROCESS_MAPPING_ID",t."PROCESS_INSTANCE_ID",t."PROCESS_DEFINITION_ID",t."PROCESS_DEFINITION_NAME",t."NODE_ID",t."NODE_NAME",t."TRANSACTOR",t."CREATE_TIME",t."TRANSACTION_TYPE",t."PARENT_PROCESS_INSTANCE_ID",t."PARENT_PROCESS_DEFINITION_ID",t."PARENT_PROCESS_DEFINITION_NAME",t."RECORD_ID",
(case when t.process_definition_name='clddsq' then '02'
                when t.process_definition_name='fmwpclsq' then '03'
                when t.process_definition_name='dyajsq' then '04'
                when t.process_definition_name='ajzfsq' then '05'
                else '01' end) ywxt--业务系统代码
 from c_wf_transaction_log t


/

