create FUNCTION "F_GET_AREA" (v_area_code varchar2)
  return VARCHAR2 as
  V_GET_DETAIL VARCHAR2(4000);
  v_result varchar2(500);
  v_index number;
  v_area_code_zx varchar2(200);
  v_code varchar2(50);
  v_area_name varchar2(50);
BEGIN
    V_GET_DETAIL:='select area_name from s_area where area_code=:area_code';
    v_area_code_zx:=v_area_code||',';
    while (length(v_area_code_zx)>0) loop
      v_index:=instr(v_area_code_zx,',');
      v_code:=substr(v_area_code_zx,0,v_index-1);
          begin
        execute immediate V_GET_DETAIL
        into v_area_name
        using v_code;
        exception when no_data_found
          then v_area_name:=v_code;
      end;
      v_result:= v_result||v_area_name;
      v_area_code_zx:=substr(v_area_code_zx,v_index+1,length(v_area_code_zx));
    end loop;
  return v_result;
END;


/

