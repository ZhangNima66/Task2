create trigger BOOK_ID_TRIGGER
  before insert
  on T_BOOKINFO
  for each row
begin

select  BOOK_ID_SEQ.NEXTVAL
   into :new.BOOK_ID
   from dual;

end book_id_trigger;
/

