create trigger MENU_AUTOINC_TG
  before insert
  on HHQ_HOBBY
  for each row
begin

select menu_autoinc_seq.nextval into :new.HOBBY_ID from dual;

end menu_autoinc_tg;
/

