create trigger TRIGER_ID
  before insert
  on ZXK
  for each row
declare
  -- local variables here
begin
  select identity_id.nextval into :new.STUDENT_ID from dual;
end triger_id;

/

