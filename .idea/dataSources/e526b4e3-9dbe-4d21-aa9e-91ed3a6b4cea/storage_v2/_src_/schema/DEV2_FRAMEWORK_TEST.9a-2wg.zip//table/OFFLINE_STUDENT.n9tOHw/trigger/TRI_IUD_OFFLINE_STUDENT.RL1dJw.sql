create trigger TRI_IUD_OFFLINE_STUDENT
  after insert or update or delete
  on OFFLINE_STUDENT
  for each row
DECLARE TYPE_LOG OFFLINE_LOG%ROWTYPE;

BEGIN TYPE_LOG.EXECUTE_DATE:=SYSTIMESTAMP;
TYPE_LOG.TABLENAME:='offline_student';
if inserting then TYPE_LOG.LOG_DATA:='{"student_id":"'||:NEW.STUDENT_ID||'","student_name":"'||:NEW.STUDENT_NAME||'","student_sex":"'||:NEW.STUDENT_SEX||'","student_age":"'||:NEW.STUDENT_AGE||'","student_no":"'||:NEW.STUDENT_NO||'","student_system":"'||:NEW.STUDENT_system||'","student_political_visage":"'||:NEW.STUDENT_POLITICAL_VISAGE||'"}';
TYPE_LOG.FIELD:='{"student_id": "'||:NEW.STUDENT_ID||'"}';
TYPE_LOG.FLAG:='i';
elsif updating then TYPE_LOG.LOG_DATA:='{"student_id":"'||:NEW.STUDENT_ID||'","student_name":"'||:NEW.STUDENT_NAME||'","student_sex":"'||:NEW.STUDENT_SEX||'","student_age":"'||:NEW.STUDENT_AGE||'","student_no":"'||:NEW.STUDENT_NO||'","student_system":"'||:NEW.STUDENT_system||'","student_political_visage":"'||:NEW.STUDENT_POLITICAL_VISAGE||'"}';
TYPE_LOG.FIELD:='{"student_id": "'||:NEW.STUDENT_ID||'"}';
TYPE_LOG.FLAG:='u';
else TYPE_LOG.FLAG:='d';
TYPE_LOG.FIELD:='{"student_id": "'||:OLD.STUDENT_ID||'"}';
  end if;
INSERT INTO OFFLINE_LOG VALUES TYPE_LOG;
END;
/

