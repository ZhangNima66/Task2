create trigger JF_USER_AUTOINC_TG
  before insert
  on JF_USER
  for each row
begin
select jf_user_autoinc_seq.nextval into :new.id from dual;
end jf_user_autoinc_tg;

/

