create view V_C_REMINDER_INFO_RECEIVER as
select t1.business_type,
       t1.kind,
       t1.title,
       t1.content,
       t1.create_time,
       t1.valid_time,
       t1.end_time,
       t1.url,
       t1.flag,
       t1.id,
       t2.id as receiver_id,
       t2.receive_state,
       t2.mobile,
       t2.receiver,
       t2.take_reminder_time,
       t2.reminder_close
       from c_reminder_info t1, c_reminder_receiver t2 where t1.id = t2.reminder_id


/

