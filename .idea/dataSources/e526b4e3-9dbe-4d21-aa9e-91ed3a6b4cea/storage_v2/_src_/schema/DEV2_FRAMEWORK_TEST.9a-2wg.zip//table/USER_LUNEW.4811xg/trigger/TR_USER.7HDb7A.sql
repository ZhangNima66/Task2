create trigger TR_USER
  before insert
  on USER_LUNEW
  for each row
begin

select user_seq.nextval into :new.id from dual;

end;
/

