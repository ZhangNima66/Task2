create trigger TRI_LU
  before insert
  on USER_LU
  for each row
declare

begin

if :new.id is null or :new.id=0 then

select seq_lu.nextval into :new.id from sys.dual; --seq_student??????????????

end if;

end tri_lu;
/

