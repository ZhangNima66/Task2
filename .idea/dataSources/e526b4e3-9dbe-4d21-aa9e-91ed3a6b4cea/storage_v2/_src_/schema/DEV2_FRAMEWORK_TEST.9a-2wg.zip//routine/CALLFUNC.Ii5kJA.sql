create FUNCTION "CALLFUNC" (p1 IN VAECHAR2) return varchar2 is
  Result Varchar2;
begin

  return(Result);
end callfunc;


/

