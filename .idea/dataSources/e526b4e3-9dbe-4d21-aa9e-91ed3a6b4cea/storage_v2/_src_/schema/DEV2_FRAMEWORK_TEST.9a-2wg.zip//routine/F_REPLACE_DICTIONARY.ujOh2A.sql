create FUNCTION f_replace_dictionary(p_kind varchar2,p_code Varchar2 )
 return  varchar2 as v_detail varchar2(1000); 
  cursor c_cursor is
    select  t.code,t.detail
      from dictionary t
 where t.kind=p_kind ;
 v_code varchar2(1000);
begin
   v_code:=p_code;
   for v_cursor in c_cursor loop
     /**
  0	局内用户
1	药品企业
2	沈阳企业
3	医疗器械企业
   **/

   v_detail:=replace(v_code,v_cursor.code,v_cursor.detail);
   v_code:=v_detail;

--遍历字典。取出code,detail。
--给一个字符串。
--替换完输出。

  end loop;
  

   return v_detail;  
end ;
/

