create view V_LYM_EMP as
select e.empno as empno,ename,sex,job,d.dname as dname,hiredate,sal,address from B_LYM_EMP e join B_LYM_DEPT d on e.deptno =d.deptno
/

