create procedure proc1
as 
totalmessages number(10);
begin 
select count(*)  into totalmessages from t_student001;
dbms_output.put_line('信息总数'||totalmessages);
end ;
/

