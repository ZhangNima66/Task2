create view V_SYSORG_QJ_NOTDEL as
Select "ORGID",'广州市食品药品监督管理局'||substr("ORGNAME",0 ,2)||'区局稽查科' as orgname,"PARENTORGID","ORGTYPE","FZRZH","FZRXM","JGDZ","YZBM","LXDH","CZHM","EMAIL","YXJXH","CREATORID","CREATOR","CREATEDTIME","LASTUPDATEDBY","LASTUPDATEDTIME","DELETEFLAG","RESERVATION01","RESERVATION02","RESERVATION03","RESERVATION04","RESERVATION05","RESERVATION06","RESERVATION07","RESERVATION08","RESERVATION09","RESERVATION10"
    from sysorg t where (t.deleteflag !='1'or t.deleteflag is null) and t.orgtype='03' and t.reservation02 in (select orgcode from s_sysorg_code_mapping where custom_code  like '______01%')


/

