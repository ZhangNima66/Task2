create FUNCTION "CXH_TEXT" (para1 in number, para2 in number)
return number
as
begin
  if para1 > para2 then
      return para1;
  else
      return para2;
  end if;
end cxh_text;
/

