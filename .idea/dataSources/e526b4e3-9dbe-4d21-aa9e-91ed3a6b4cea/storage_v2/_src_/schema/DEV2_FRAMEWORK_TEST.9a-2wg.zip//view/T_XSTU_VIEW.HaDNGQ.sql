create view T_XSTU_VIEW as
select STUID,STUNAME,STUSEX_detail,GRADE_DETAIL,CLASS_DETAIL,STUSEX,CLASS,GRADE
    from T_XStu
   where T_XStu.sdeleted!=1


/

