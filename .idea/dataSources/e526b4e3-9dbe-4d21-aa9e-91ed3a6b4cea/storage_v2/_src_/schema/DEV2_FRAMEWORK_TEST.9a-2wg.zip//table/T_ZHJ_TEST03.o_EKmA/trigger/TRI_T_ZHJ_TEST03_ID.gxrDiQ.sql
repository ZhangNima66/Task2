create trigger TRI_T_ZHJ_TEST03_ID
  before insert
  on T_ZHJ_TEST03
  for each row
declare
  -- local variables here
begin
  select seq_t_zhj_test03_id.nextval into :new.id from dual;
end TRI_t_ZHJ_TEST03_id;

/

