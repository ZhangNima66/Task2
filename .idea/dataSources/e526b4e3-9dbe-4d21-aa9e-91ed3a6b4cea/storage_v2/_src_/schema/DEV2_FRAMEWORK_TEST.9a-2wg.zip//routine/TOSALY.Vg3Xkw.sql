create PROCEDURE "TOSALY" () IS
TYPE CURSOR myCusor IS SELECT * FROM EMP;
clrec myCusor%rowtype;
jobs VARCHAR2(9);
deptnos NUMBER(2);
begin
 OPEN myCusor;
 FOR clrec IN myCusor LOOP
     select JOB INTO jobs,DEPTNO INTO deptnos FROM EMP WHERE DEPTNO=clrec.DEPTNO;
     IF jobs='MANAGER' AND deptnos='10' THEN
       UPDATE EMP SET SAL=SAL*1.15 WHERE EMPNO=clrec.EMPNO;
     ELSE IF jobs='CLEAR' AND deptnos='10' THEN
       UPDATE EMP SET SAL=SAL*1.15 WHERE EMPNO=clrec.EMPNO;
     END IF;
 END LOOP;
 CLOSE myCusor;
END;


 /

