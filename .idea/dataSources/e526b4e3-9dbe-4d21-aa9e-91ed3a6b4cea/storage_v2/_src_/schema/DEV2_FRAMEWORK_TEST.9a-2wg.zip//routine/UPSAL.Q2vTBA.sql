create PROCEDURE "UPSAL" (emp_id integer) IS
BEGIN
  for rc in (select job, place from q_emp where empno = emp_id) loop
    if rc.job = 'MANAGER' and place = 'DALLAS' then
      update q_emp set sal = sal * 1.15;
    end if;
    if rc.job = 'CLERK' and place = 'NEW YORK' then
      update q_emp set sal = sal * 0.95;
      end if;
   end loop;
END;


/

