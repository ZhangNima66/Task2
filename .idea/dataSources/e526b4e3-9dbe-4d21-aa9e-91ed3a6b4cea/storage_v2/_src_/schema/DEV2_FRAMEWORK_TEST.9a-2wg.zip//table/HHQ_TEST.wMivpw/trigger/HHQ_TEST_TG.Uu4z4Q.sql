create trigger HHQ_TEST_TG
  before insert
  on HHQ_TEST
  for each row
  when (new.USER_ID is null)
begin
  select HHQ_TEST_SEQUENCE.nextval into :new.USER_ID from dual;
end;
/

