create FUNCTION "F_BBTJ_XCLMJ_TJ" (v_col varchar2) return number is
  ----报表统计——健康教育宣传栏出版情况汇总表——统计面积
  --lym，20130416

  v_sql_mj    varchar2(4000);
  v_result_id varchar2(4000);
  v_mj        number;

begin
  v_result_id := to_char('''' ||
                         replace(replace(v_col, ';', ','), ',', ''',''') || '''');
  v_sql_mj    := 'select sum(t2.mj) from  B_HEDU_SHOWBOARD_INFO t2 where t2.valid=''1'' and  t2.id in (' ||
                 v_result_id || ')';
  execute immediate v_sql_mj
    into v_mj;
  v_mj := nvl(v_mj, 0);
  return v_mj;
end;


/

