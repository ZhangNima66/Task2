create FUNCTION "F_MULTI_COL_TO_STRING" (v_col varchar2,
                                                 v_cv_tab varchar2,
                                                 v_cv_kind varchar2)
  return varchar2 is
  ----多选字段code值翻译成一个字段。字段值用‘;'隔开
  --lym，20130224
  v_sql_code varchar2(4000);
  v_sql_detail varchar2(4000);
  v_num        int;
  v_code       varchar2(50);
  v_result     varchar(4000);
begin
   v_sql_code:=replace(v_col,';',''',''');
   v_sql_code:=''''||v_sql_code||'''';
   v_sql_detail :='select wm_concat(detail) from  '|| v_cv_tab||' where kind='''|| v_cv_kind||''''||' and code in ('||v_sql_code||')';
   execute immediate v_sql_detail  into v_result;
   return v_result;
end;


/

