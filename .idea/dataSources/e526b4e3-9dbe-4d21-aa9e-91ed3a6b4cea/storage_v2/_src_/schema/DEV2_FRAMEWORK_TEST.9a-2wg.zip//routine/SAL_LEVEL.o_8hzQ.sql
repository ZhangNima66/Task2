create FUNCTION "SAL_LEVEL" (no q_emp.empno%type)return char as
vjob q_emp.job%type;
vsal q_emp.sal%type;
vmesg char(50);
begain
select job,sal into vjob,vsal from q_emp where empno = no;
if vjob = 'clerk' then
  if vsal >= 1500 and vsal <= 2500 then
    vmesg := 'salary is ok';
  else
      vsal := 1500;
      vmesg := 'update salary to'||to_char(vsal);
  end if;
  elseif vjob = 'salesman'then
  if vsal >= 2501 and vsal <= 3500 then
    vmesg := 'salary is ok';
  else
      vsal := 2501;
      vmesg := 'update salary to'||to_char(vsal);
  end if;
  elseif vjob = 'analyst'then
  if vsal >= 3501 and vsal <= 4500 then
    vmesg := 'salary is ok';
  else
      vsal := 3501;
      vmesg := 'update salary to'||to_char(vsal);
  end if;
  else
    if vsal >= 4500 then
      vmesg := 'salary is ok';
    else
       vsal := 4501;
      vmesg := 'update salary to'||to_char(vsal);
  end if;
  end if;
  update q_emp set sal = vsal where empno = no;
  return vmesg;
  end;
/

