create trigger USER_TRIG3
  before insert
  on USERTABLE1
  for each row
  when (New.Id Is Null)
Begin
Select emp_sequence3.Nextval Into:New.Id From dual;
End;

/

