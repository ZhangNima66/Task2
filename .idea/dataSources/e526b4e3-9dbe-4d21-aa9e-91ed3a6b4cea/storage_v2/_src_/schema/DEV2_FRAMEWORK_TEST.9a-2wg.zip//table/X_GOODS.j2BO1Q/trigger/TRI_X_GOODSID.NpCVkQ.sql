create trigger TRI_X_GOODSID
  before insert
  on X_GOODS
  for each row
declare
  -- local variables here
begin
  select seq_X_Goods.Nextval into :new.GOODSID from dual;
end Tri_X_GoodsId;
/

